<?php
    $inventors = array(
        "Newton" => "Gravity",
        "Albert" => "Energy",
        "Edison" => "Bulb",
        "Tesla" => "AC"
    );

    foreach ($inventors as $name => $invention) 
    {
        echo "$name => $invention<br>";
    }
?>
