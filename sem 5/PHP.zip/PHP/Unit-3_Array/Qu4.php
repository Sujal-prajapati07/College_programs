<?php
	$arr = array(32,43,13,56,75,33,65);
	echo "Lowest: " . min($arr) . "<br>";
	echo "Highest: " . max($arr);
?>
