<?php
    $colors = array("Red", "Green", "Blue", "Yellow", "Purple");

    foreach ($colors as $c) 
    {
        echo "$c<br>";
    }
?>
