<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<style>
		h2{
			text-align: center;
			margin-top: 30px;
		}
	</style>
</head>
<body>
	<h2>Welcome to the HospitalManagement</h2>

	<?php include 'Qu7_footer_1.php';?>
</body>
</html>