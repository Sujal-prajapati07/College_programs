<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<form action="Qu4_2.php" method="post">
		String1:<input type="text" name="str1">
		<br><br>
		String2:<input type="text" name="str2">
		<br><br>
		String3:<input type="text" name="str3">
		<br><br>
		String4:<input type="text" name="str4">
		<br><br>
		String5:<input type="text" name="str5">
		<br><br>
		<input type="submit" name="Submit">
	</form>
</body>
</html>
