<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<div style="background: black;color:white;text-align: center;">
		<h1>HospitalManagement</h1>
	</div>
</body>
</html>