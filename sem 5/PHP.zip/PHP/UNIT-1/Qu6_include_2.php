<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<?php include 'Qu6_header_1.php';?>

	<h2 style="color: red;">Welcome to the home page</h2>
</body>
</html>