<?php
	$String1 = $_POST['s1']; 
	$String2 = $_POST['s2'];
	$String3 =	$_POST['s3'];

	echo "<h1>$String1"."$String2"."$String3</h1><br><br>";
	print("<h1>$String1"."$String2"."$String3</h1>");
?>