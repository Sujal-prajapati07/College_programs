<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body style="background-color: yellow;">
	<?php
	$hobbies = <<<hobby

		<h1>Hobbies</h1>
			<h3>Cricket</h3>
			<h3>Photography</h3>
			<h3>Reading</h3>
			<h3>GYM</h3>
		hobby;
	echo "$hobbies";
	?>
</body>
</html>