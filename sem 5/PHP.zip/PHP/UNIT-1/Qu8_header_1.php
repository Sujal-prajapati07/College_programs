<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<h1 style="text-align: center;">Hobbies</h1>
	<div style="background: yellow;text-align: center;">
		<b>Cricket</b>
		<br>
		<b>Game</b>
		<br>
		<b>Reading</b>
	</div>
</body>
</html>