<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<form method="post" action="Qu3_2.php">
		Enter the String1:<input type="text" name="s1">
		<br><br>
		Enter the String2:<input type="text" name="s2">
		<br><br>
		Enter the String3:<input type="text" name="s3">
		<br><br>
	<input type="submit" name="Submit">
	</form>
</body>
</html>