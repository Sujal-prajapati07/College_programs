<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<form action="Qu2_2.php" method="post">
		Number1:<input type="number" step="any" name="number1">
		<br><br>
		Number2:<input type="number" step="any" name="number2">
		<br><br>
		<input type="Submit" value="Submit">
	</form>
</body>
</html>

<!-- step="any" is allows to float number -->