<?php
require "Qu3_1.php";
echo "© 2025 $siteName.All rights reserved.";
?>