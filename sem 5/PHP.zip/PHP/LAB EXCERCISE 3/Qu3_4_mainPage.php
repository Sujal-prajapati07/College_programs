<?php
include "Qu3_2_header.php";
echo "----------------------------------<br>";
echo "This is the main content of the homepage<br>";
echo "----------------------------------<br>";
include "Qu3_3_footer.php";
?>