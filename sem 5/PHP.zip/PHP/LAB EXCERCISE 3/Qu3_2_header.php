<?php
require "Qu3_1.php";
echo "welcome to $siteName<br>";
?>