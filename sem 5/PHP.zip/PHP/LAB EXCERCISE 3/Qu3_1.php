<?php
$siteName="My PHP Site"; 
?>