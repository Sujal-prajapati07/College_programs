<?php
	echo "<h2>"; 
	echo "Year/Month/Date : ".date("Y/m/d")."<br>";
	echo "Year.Month.Date : ".date("Y.m.d")."<br>";
	echo "Year : ".date("Y")."<br>";
	echo "Date : ".date("d")."<br>";
	echo "</h2>";
?>