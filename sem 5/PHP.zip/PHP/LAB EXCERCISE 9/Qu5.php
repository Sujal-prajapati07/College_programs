<?php
	$str="I like cats.cats are cute";

	$newStr=str_replace("cats", "dogs", $str);

	echo "<h1>$newStr</h1>";
?>