<?php
	$str="Hello World";

	if(str_starts_with($str,"Hello"))
	{
		echo "String start with Hello";
	}
	else
	{
		echo "String Does not start with Hello";
	}
?>