<?php 
	for ($i=1; $i <=10 ; $i++) 
	{ 
		if ($i==3) 
		{
			continue;
		}
		echo "<h1>$i</h1>";
	}
?>