<?php
$fruits=array("Apple", "Mango", "Banana","Orange");

foreach ($fruits as $f) 
{
	echo "<h1>";
	echo "$f";
	echo "</h1>";
}
?>