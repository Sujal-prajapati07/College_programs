<?php
$i=1;
while ($i<=20) 
{
	if ($i%2==0) 
	{
		echo "<h1>";
		echo "$i";
		echo "</h1>";
	}
	$i++;
}
?>