<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<form method="post" action="Qu15_2.php">
		Enter the number:<input type="number" name="num1">
		<br><br>
		<input type="submit" value="Check the day" name="check">
	</form>
</body>
</html>