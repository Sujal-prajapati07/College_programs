<?php
$i=1;
do 
{
	echo "<h1>$i</h1>";
	$i++;
} while ($i<=5);
?>