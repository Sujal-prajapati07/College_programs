<?php 
	for ($i=1; $i <=10 ; $i++) 
	{ 
		if ($i==5) 
		{
			break;
		}
		echo "<h1>$i</h1>";
	}
?>