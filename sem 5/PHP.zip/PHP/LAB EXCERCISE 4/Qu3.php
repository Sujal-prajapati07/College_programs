<?php
for ($i=1; $i <=10 ; $i++) 
{ 	
	echo "<h1>";
	echo "$i<br>";
	echo "</h1>";
}
?>