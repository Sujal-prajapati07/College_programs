<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<form method="post" action="Qu10_2.php">
		Enter the number1:<input type="number" name="num1">
		<br><br>
		Enter the number2:<input type="number" name="num2">
		<br><br>
		<input type="submit" value="Check Product" name="check">
	</form>
</body>
</html>