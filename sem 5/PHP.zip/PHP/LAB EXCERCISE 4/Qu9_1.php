<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<form method="post" action="Qu9_2.php">
		Enter Marks for Maths:<input type="number" name="m1">
		<br><br>
		Enter Marks for Science:<input type="number" name="m2">
		<br><br>
		Enter Marks for English:<input type="number" name="m3">
		<br><br>
		<input type="submit" value="Check the result" name="check">
	</form>
</body>
</html>