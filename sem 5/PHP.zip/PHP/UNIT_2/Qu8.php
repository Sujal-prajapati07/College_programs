<?php
	function Addition($a,$b)
	{
		$sum=$a+$b;
		echo "<h1>Addition of both value is: $sum</h1><br>";
	}

	Addition(5,2);
	Addition(4,4);
	Addition(8,5);
	Addition(6,3);
	Addition(9,6);
	Addition(10,15);
?>