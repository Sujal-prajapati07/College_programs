<?php
	function greet()
	{
		echo "<h1>Welcome to PHP programming!</h1>";
	}

	greet();
	greet();
	greet();
	greet();
	greet();
	greet();
	greet();
	greet();
?>