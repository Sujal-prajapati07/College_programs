<?php
	// include "q11_1.php";//it's not necessary for the file to exist in include
require "q11_1.php"; //in require the file name specified must exist...it’s compulsory. Otherwise it will give an error
?>