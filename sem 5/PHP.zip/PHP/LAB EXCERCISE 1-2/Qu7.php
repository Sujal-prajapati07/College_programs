<?php
	$message="Hello World";

	$message.=",Welcome to PHP";

	echo "$message";
?>