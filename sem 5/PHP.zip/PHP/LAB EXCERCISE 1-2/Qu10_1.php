<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
</head>
<body>
    <a href="Qu10_2.php?name=xyz&age=25">Click here to send name and age</a>
</body>
</html>
