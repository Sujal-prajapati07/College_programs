<?php
	const school_name="Anupam school";

	$name="Sujal";
	$class="12th";
	$grade="A";

	echo "School name is : ".school_name."<br>";
	echo "Class : $class<br>";
	echo "Grade : $grade<br>";
?>