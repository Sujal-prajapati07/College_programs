<?php
	$a=25;
	$b=40;

	if($a>$b)
	{
		echo "$a is greater than $b<br>";
	}
	else
	{
		echo "$b is greater than $a<br>";
	}

	if($a<$b)
	{
		echo "$a is less than $b<br>";
	}
	else
	{
		echo "$b is less than $a<br>";
	}

	if($a>=$b)
	{
		echo "$a is greater than or equal to $b<br>";
	}
	else
	{
		echo "$b is greater than or equal to $a<br>";
	}

	if($a<=$b)
	{
		echo "$a is less than or equal to $b<br>";
	}
	else
	{
		echo "$b is less than or equal to $a<br>";
	}

?>