<?php
	$name=$_POST['name1'];
	$email=$_POST['email1'];

	echo "<h1>Thank you $name , for registering with the email:$email</h1>";
?>