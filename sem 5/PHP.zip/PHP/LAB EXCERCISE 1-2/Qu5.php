<?php
$num = 20;
echo "Original value of number: $num<br>";

$num += 5;
echo "After 5 add = $num<br>";

$num -= 2;
echo "After 2 substract =$num<br>";

$num *= 3;
echo "After multiply 3 =$num<br>";

$num /= 6;
echo "After divide by 6  =$num<br>";

$num %= 4;
echo "After modulo 4 =$num<br>";
?>
