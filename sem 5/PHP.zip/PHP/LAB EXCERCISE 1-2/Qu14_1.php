<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<form action="Qu14_2.php" method="post">
		Name:<input type="text" name="name1">
		<br><br>
		Email:<input type="text" name="email1">
		<br><br>
		<input type="submit" name="Submit">
	</form>
</body>
</html>